// Shannon Duvall
// Runs the interpreter

public class Main {
	public static void main(String[] args){
		Interpreter interpreter = new Interpreter();
		interpreter.promptLoop();
	}
}
